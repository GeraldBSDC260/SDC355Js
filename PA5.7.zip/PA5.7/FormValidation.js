/*
Name: Gerald Blackwell
Date: 02/28/2026
Purpose: This file enables live client-side validation using jQuery
and validator.js. It validates email, password strength, website URL,
and age. On success, the form clears and displays an alert.
*/

$(document).ready(function () {

    function validateEmail() {
        const email = $("#email").val();

        if (!validator.isEmail(email) ||
            !(email.endsWith(".com") || email.endsWith(".edu"))) {
            $("#emailError").text("Enter a valid email address.");
            return false;
        }

        $("#emailError").text("");
        return true;
    }

    function validatePassword() {
        const password = $("#password").val();

        const strongPassword =
            password.length >= 8 &&
            /[A-Z]/.test(password) &&
            /[a-z]/.test(password) &&
            /[0-9]/.test(password);

        if (!strongPassword) {
            $("#passwordError").text(
                "Password must be 8+ chars with upper, lower, and number."
            );
            return false;
        }

        $("#passwordError").text("");
        return true;
    }

    function validateWebsite() {
        const website = $("#website").val();

        if (!validator.isURL(website, { protocols: ['http','https'], require_protocol: true })) {
            $("#websiteError").text("Enter a valid URL starting with http:// or https://");
            return false;
        }

        $("#websiteError").text("");
        return true;
    }

    function validateAge() {
        const age = $("#age").val();

        if (!validator.isInt(age, { min: 1 })) {
            $("#ageError").text("Enter a valid age (must be 1 or higher).");
            return false;
        }

        $("#ageError").text("");
        return true;
    }

    function validateName() {
        const name = $("#fullName").val();

        if (validator.isEmpty(name)) {
            $("#nameError").text("Full name is required.");
            return false;
        }

        $("#nameError").text("");
        return true;
    }

    // Live validation events
    $("#email").on("input", validateEmail);
    $("#password").on("input", validatePassword);
    $("#website").on("input", validateWebsite);
    $("#age").on("input", validateAge);
    $("#fullName").on("input", validateName);

    // jQuery form submission
    $("#signupForm").on("submit", function (event) {
        event.preventDefault();

        const isValid =
            validateName() &&
            validateEmail() &&
            validatePassword() &&
            validateWebsite() &&
            validateAge();

        if (isValid) {
            alert("Form submitted successfully!");
            $("#signupForm")[0].reset();
        }
    });

});